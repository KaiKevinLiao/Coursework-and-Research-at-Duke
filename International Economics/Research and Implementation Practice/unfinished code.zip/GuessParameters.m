function [kappatilde] = guess_parameters(N,K)
%guess the parameters
%   This function is left blanked on purpose
kappatilde
end

