function [L, underline_x] = guess_L_and_x(underline_x_ub, N, K)
%STEP 5 Guess L and underline_x
%   Not yet coded, remenber x should below x_ub
L = zeros(K, N)
underline_x = zeros(K, N);
for k = 1:K
    for i = 1:N
        
    end
end
end

