function [a] = test()
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here
a = []
a = [a,1]
end

