function [Y] = solve_for_
Y(pi, mu, gamma, nu, N, K)
%STEP 1 Solve for Y
%   Need to check the format of input

%Compute B matrix
B = zeros(N*K, N*K);
for k = 1:K
    for o = 1:N
        for l = 1:K
            for i = 1:N
                B((k-1)*N+o, (l-1)*N+i) = pi(k, o, i)*(mu(k,i)*gamma(l,i)+...
                    (1-gamma(l,i))\nu(l,k,i));
            end
        end
    end
end

%Compute A matrix
A = [eyes(N*K) - B;T = ones(1, N*K)]

%Compute b matrix
b = zeros(N*K+1, 1);
b(N*K+1, 1) = 0;

%Solve for Y by AY = b
Y = linsolve(A, B);

end

