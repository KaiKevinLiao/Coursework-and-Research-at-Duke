x = [2,3,4]
%sigma = [7,8,9]
t = stdint(x, sigma)
b = test()

syms x
sigma = 1;
omega = 1
eqn = exp(sigma.*sigma./2).*normcdf(sigma-(log(x)-sigma))-x.*normcdf(-log(x)./sigma) == omega
S = vpasolve(eqn,x)

a = [1, 2, 3]
b = repmat(a,4, 1
)

